package application;

import java.lang.Math;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class ZahlenSysteme_umwandler {

	static List<Double> eD = new ArrayList<Double>(); // f�r vonDecNachkommer zum rechnen
	boolean isMinus = false;

	public ZahlenSysteme_umwandler() {
		// TODO Auto-generated constructor stub
	}

	// Main Metode zum Testen
	//public static void main(String[] args) throws EigeneCheckedException {
		 //aufDec("2a2b", 13); // vonDec(155,16); //
		 //System.out.println(Konverter("a",16, 10)); // aTest("2a");
		//String test = vonDecNachKommer(10, 16);
		//System.out.println(test);
		//Konverter("10,12", 10, 10);
		//aufDecNachKOMMER("5", 10);
		//infoBox("YOUR INFORMATION HERE", "TITLE BAR MESSAGE");
		//System.out.println(isAlpha2("l"));
		//System.out.println(isMinus("10"));
		
		//rechner2("-11", 10, "-12", 10, 10, "+");
	//}

	
	// Test rechner
	
	public static String rechnerKomma(String e1, int z1, String e2, int z2, int zA, String zeichen) throws EigeneCheckedException{
	//Minues Merken und erstmals rausnehmen
		boolean e1m = false;
		boolean e2m = false;
		//minus erkennen, merken und l�schen
		if(isMinus(e1))
		{
			e1 = e1.replace("-","");
			e1m = true;
		}
		
		if(isMinus(e2))
		{
			e2 = e2.replace("-","");
			e2m = true;
		}
		
		
		
		
		//e1 zerlegen:
		
		boolean kommer = false;
		String vorKomma1 = "";
		String nachKomma1 = "";

		for (char c : e1.toCharArray()) {

			if (c == ',') {
				if (kommer) { // zu viele Kommers
					throw new EigeneCheckedException("zu viele Kommer");
				}
				kommer = true;
			}

			if (!kommer) { // wenn noch kein Komma vorgekommen ist dann wird es in VorKomma sortier
				if (c != ',') {
				vorKomma1 = vorKomma1 + c;}
			} else {// wenn schon ein Komma vorgekommen ist dann wird es in NachKommer sortier
				if (c != ',') {
				nachKomma1 = nachKomma1 + c;}
			}

		}
		//e2 zerlegen
		boolean kommer2 = false;
		String vorKomma2 = "";
		String nachKomma2 = "";
		for (char c : e2.toCharArray()) {

			if (c == ',') {
				if (kommer2) { // zu viele Kommers
					throw new EigeneCheckedException("zu viele Kommer");
				}
				kommer2 = true;
			}

			if (!kommer2) { // wenn noch kein Komma vorgekommen ist dann wird es in VorKomma sortier
				if (c != ',') {
				vorKomma2 = vorKomma2 + c;}
			} else {// wenn schon ein Komma vorgekommen ist dann wird es in NachKommer sortier
				if (c != ',') {
				nachKomma2 = nachKomma2 + c;}
			}

		}
		//Rechner mit Komma
		System.out.println("Rechner: ");

		int zwischenS1 = aufDec(vorKomma1,z1);
		int zwischenS2 = aufDec(vorKomma2, z2);
		
		double zwischenS3; 
		double zwischenS4;
		//pr�fen ob kommer vorhanden
		if(nachKomma1 == "")
		{
			zwischenS3 = 0;
		}
		else {
			zwischenS3 = aufDecNachKOMMER(nachKomma1, z1);
		}
		
		if(nachKomma2 == "")
		{
			zwischenS4 = 0;
		}
		else {
			zwischenS4 = aufDecNachKOMMER(nachKomma2, z2);
		}
		//zwischenS3 = aufDecNachKOMMER(nachKomma1, z1);
		//zwischenS4 = aufDecNachKOMMER(nachKomma2, z2);
		
		//Wenn Minus zahl dabei jetzt auf minus bringen
		if(e1m ==true)
			{
				zwischenS1 *= -1;
				zwischenS3 *= -1;
			}
		if(e2m ==true)
			{
				zwischenS2 *= -1;
				zwischenS4 *= -1;

			}
		
		
		double ergebnisDec;

		// welche Rechnung?
		switch (zeichen) {
		case "+":
			ergebnisDec = zwischenS1 + (zwischenS3/10) + zwischenS2 + (zwischenS4 / 10);
			break;

		case "-":
			ergebnisDec = (zwischenS1+ (zwischenS3/10)) - (zwischenS2 + (zwischenS4/10));
			break;

		case "*":
			ergebnisDec = (zwischenS1 + (zwischenS3/10)) * (zwischenS2 + (zwischenS4/10));
			break;

		case "/":
			ergebnisDec = (zwischenS1 + (zwischenS3/10))  / (zwischenS2 + (zwischenS4/10));
			break;

		default:
			throw new EigeneCheckedException("Falscher Operator");
		}
		//ZERLGEN 
		String ergebinsmitKommer = Double.toString(ergebnisDec);
		
		
		//Minus rausfischen!!
		boolean minusNachKommer = false; //merkt ob minus
		if(isMinus(ergebinsmitKommer)) 
		{
			minusNachKommer = true;
			ergebinsmitKommer = ergebinsmitKommer.replace("-", "");
		}
		
		
		
		boolean kommer3= false;
		String vorKomma3 = "";
		String nachKomma3 = "";
		for (char c : ergebinsmitKommer.toCharArray()) {

			if (c == '.') {
				if (kommer3) { // zu viele Kommers
					throw new EigeneCheckedException("zu viele Kommer!!!");
				}
				kommer3 = true;
			}

			if (!kommer3) { // wenn noch kein Komma vorgekommen ist dann wird es in VorKomma sortier
				if (c != '.') {
				vorKomma3 = vorKomma3 + c;}
			} else {// wenn schon ein Komma vorgekommen ist dann wird es in NachKommer sortier
				if (c != '.') {
				nachKomma3 = nachKomma3 + c;}
			}

		}
		
		//Zerlegen ENDE
		int vorKommaInt =  Integer.parseInt(vorKomma3);
		String ergebisVorKomma = vonDec(vorKommaInt, zA);
		
		double ergebnisNachKommerDouble = Double.parseDouble(nachKomma3);
		String ergebnisNachKommer = vonDecNachKommer(ergebnisNachKommerDouble, zA);
		
		String ergebnisEnde = ergebisVorKomma +"," + ergebnisNachKommer;
		//wenn minus dabei ==> minus wieder einf�gen
		if(minusNachKommer)
		{
			ergebnisEnde = "-" + ergebnisEnde;
		}
		
		System.out.println("\n \n");
		System.out.println("Ergebnis Aus rechnung: " + ergebnisEnde);
		
		return ergebnisEnde;
	}
	
	
	public static String rechner2(String e1, int z1, String e2, int z2, int zA, String zeichen)
			throws EigeneCheckedException { // in Laptop version �bernehmen
		// test lauf: rechner("A04bc",16,"11000",2,10);
		System.out.println("Rechner: ");
		
		//minus merk variblen
		boolean e1m = false;
		boolean e2m = false;
		//minus erkennen, merken und l�schen
		if(isMinus(e1))
		{
			e1 = e1.replace("-","");
			e1m = true;
		}
		
		if(isMinus(e2))
		{
			e2 = e2.replace("-","");
			e2m = true;
		}
		//-------
		
		
		//auf dezimal bringen	
		int zwischenS1 = aufDec(e1, z1);
		int zwischenS2 = aufDec(e2, z2);
		
		//Wenn Minus zahl dabei jetzt auf minus bringen
		if(e1m ==true)
		{
			zwischenS1 *= -1;
		}
		if(e2m ==true)
		{
			zwischenS2 *= -1;
		}
		
		// welche Rechnung?
		int ergebnisDec;
		
		switch (zeichen) {
		case "+":
			ergebnisDec = zwischenS1 + zwischenS2;
			break;

		case "-":
			ergebnisDec = zwischenS1 - zwischenS2;
			break;

		case "*":
			ergebnisDec = zwischenS1 * zwischenS2;
			break;

		case "/":
			ergebnisDec = zwischenS1 / zwischenS2;
			break;

		default:
			throw new EigeneCheckedException("Falscher Operator");
		}
		//falls minus Zahl ==> umwandeln auf positive zahl und Minus merken
		System.out.println("Ergebnis DEC MINUS :" + ergebnisDec);
		boolean minusMerkerErgebnis = false;
		if(ergebnisDec < 0)
		{
			ergebnisDec *= -1;
			minusMerkerErgebnis = true;
		}
		
		String ergebisZA = vonDec(ergebnisDec, zA);
		//fals minus auf Minus brigen
		if(minusMerkerErgebnis)
		{
			ergebisZA = "-" + ergebisZA;
		}
		System.out.println("\n \n");
		System.out.println("Ergebnis Aus rechnung: " + ergebisZA);
		return ergebisZA;

	}

	public String rechner(String e1, int z1, String e2, int z2, int zA, String zeichen) throws EigeneCheckedException { // in
																														// Laptop
																														// version
																														// �bernehmen
		// test lauf: rechner("A04bc",16,"11000",2,10);
		System.out.println("Rechner: ");

		int zwischenS1 = aufDec(e1, z1);
		int zwischenS2 = aufDec(e2, z2);

		int ergebnisDec;

		// welche Rechnung?
		switch (zeichen) {
		case "+":
			ergebnisDec = zwischenS1 + zwischenS2;
			break;

		case "-":
			ergebnisDec = zwischenS1 - zwischenS2;
			break;

		case "*":
			ergebnisDec = zwischenS1 * zwischenS2;
			break;

		case "/":
			ergebnisDec = zwischenS1 / zwischenS2;
			break;

		default:
			throw new EigeneCheckedException("Falscher Operator");
		}

		String ergebisZA = vonDec(ergebnisDec, zA);

		System.out.println("\n \n");
		System.out.println("Ergebnis Aus rechnung: " + ergebisZA);
		return ergebisZA;

	}

	public void kommerZerleger(String eingabe) throws EigeneCheckedException {
		boolean kommer = false;
		String vorKomma = "";
		String nachKomma = "";
		for (char c : eingabe.toCharArray()) {

			if (c == ',') {
				if (kommer) { // zu viele Kommers
					throw new EigeneCheckedException("zu viele Kommer");
				}
				kommer = true;
			}

			if (!kommer) { // wenn noch kein Komma vorgekommen ist dann wird es in VorKomma sortier
				if (c != ',') {
				vorKomma = vorKomma + c;}
			} else {// wenn schon ein Komma vorgekommen ist dann wird es in NachKommer sortier
				if (c != ',') {
				nachKomma = nachKomma + c;}
			}

		}

	}

	public static String Konverter(String startWert, int startZahlenSystem, int endZahlensystem)
			throws EigeneCheckedException {
		
		String r;
		String rV;
		String rN;
		
		//kommerZerleger();
		boolean kommer = false;
		String vorKomma = "";
		String nachKomma = "";
		for (char c : startWert.toCharArray()) {

			if (c == ',') {
				if (kommer) { // zu viele Kommers
					throw new EigeneCheckedException("zu viele Kommer");
				}
				kommer = true;
			}

			if (!kommer) { // wenn noch kein Komma vorgekommen ist dann wird es in VorKomma sortier
				if (c != ',') {
				vorKomma = vorKomma + c;}
			} else {// wenn schon ein Komma vorgekommen ist dann wird es in NachKommer sortier
				if (c != ',') {
				nachKomma = nachKomma + c;}
			}

		}
		
		if(!kommer)
		{
			r = vonDec(aufDec(startWert, startZahlenSystem), endZahlensystem);
		}
		else
		{
			rV= vonDec(aufDec(vorKomma, startZahlenSystem), endZahlensystem);
			//double vDnK = aufDecNachKOMMER(nachKomma, startZahlenSystem); 					//vonDecNachKommer()
			rN= vonDecNachKommer(aufDecNachKOMMER(nachKomma, startZahlenSystem), endZahlensystem);
			r = rV + "," + rN; 			
		}
		
		System.out.println(r);
		return r;

	}

	public static String[] eingabeUmwandler(String eingabeD) // Um Buchstaben in Zahlen umzuwandeln
	{

		String eingabe = eingabeD.toUpperCase();
		System.out.println("TO UPPER CASE: " + eingabe);
		String[] split2 = s_Split(eingabe);

		for (int i = 0; i < split2.length; i++) {
			switch (split2[i]) // Zahlen �ber 9 in Buchstaben umwandeln / unter 9 in List �bergeben
			{
			case "A":
				split2[i] = "10";
				break;

			case "B":
				split2[i] = "11";
				break;

			case "C":
				split2[i] = "12";
				break;

			case "D":
				split2[i] = "13";
				break;

			case "E":
				split2[i] = "14";
				break;

			case "F":
				split2[i] = "15";
				break;

			case "G":
				split2[i] = "16";
				break;

			case "H":
				split2[i] = "17";
				break;

			case "I":
				split2[i] = "18";
				break;

			case "J":
				split2[i] = "19";
				break;

			case "K":
				split2[i] = "20";
				break;

			case "L":
				split2[i] = "21";
				break;

			case "M":
				split2[i] = "22";
				break;

			case "N":
				split2[i] = "23";
				break;

			case "O":
				split2[i] = "24";
				break;

			case "P":
				split2[i] = "25";
				break;

			case "Q":
				split2[i] = "26";
				break;

			case "R":
				split2[i] = "27";
				break;

			case "S":
				split2[i] = "28";
				break;

			case "T":
				split2[i] = "29";
				break;

			case "U":
				split2[i] = "30";
				break;

			case "V":
				split2[i] = "31";
				break;

			case "W":
				split2[i] = "32";
				break;

			case "X":
				split2[i] = "33";
				break;

			case "Y":
				split2[i] = "34";
				break;

			case "Z":
				split2[i] = "35";
				break;
			}
		}
		return split2;

	}

	// Funktion wird nicht mehr verwendet
	public static String[] s_Split(String number) // Stings zerlegen
	{
		String[] split = number.split("");
		// Ausgabe
		// for(int i=0;i<split.length;i++)
		// System.out.println(split[i]);
		return split;
	}

	public static int aufDec(String eingabe, int ak_zs) throws EigeneCheckedException { // beliebiges Zahlensystem auf
																						// Decimal bringen
		eingabe.toUpperCase();
		// Plausi check
		if (eingabe.length() > 8) // stackoverflow vermeiden
		{
			throw new EigeneCheckedException("Eingabe zu gro� \n Stack Overflow Gefahr");
		}
		if (eingabe.isEmpty()) {
			throw new EigeneCheckedException("Eigabe ist leer");
		}

		if (ak_zs < 2 || ak_zs > 36) {
			System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 2-36");
			throw new EigeneCheckedException("Die angegebene Basis liegt nicht im Bereich zwischen 2-36 \n Falsche Basis");
		}
		// Eingabe pr�fen
		if (ak_zs <= 10) // pr�fe ob Buchstaben gebraucht werden wenn nicht wird geblockt
		{
			System.out.println("Basis kleiner 11!");
			System.out.println(eingabe);
			if (isAlpha2(eingabe)) // �berarbeiten!!!!!
			{
				System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 11-36");
				throw new EigeneCheckedException("Keine Buchstaben erlaubt \n Die angegebene Basis liegt nicht im Bereich zwischen 11-36");
			}

		}

		else {
			for (char c : eingabe.toCharArray()) {
				String cAufString = Character.toString(c);
				if (isAlpha2(cAufString)) {

					eingabe.toUpperCase();
					// Pr�fen auf buchstaben mit charackter stadt swich case
					if (c < 'Z' - (25 - (ak_zs - 10)) && (c <= 'Z' && c >= 'A')) // welche Zahlen darf man verwenden
					{
						System.out.println("zwischen A-Z");
						System.out.println(c + ": ist erlaubt");
					} else if (c < 'z' - (25 - (ak_zs - 10)) && (c <= 'z' && c >= 'a')) {
						System.out.println("zwischen a-z");
						System.out.println(c + ": ist erlaubt");
					} else {
						System.out.println("NICHT ERLAUBT!!!");
						System.out.println(c + ": ist NICHT erlaubt");
						char cU = Character.toUpperCase(c);
						throw new EigeneCheckedException("Dieser Buchstabe: " + cU + " ist bei dem aktuelen Zahlensystem (" + ak_zs + ") nicht erlaubt");
					}

				}
				else {
					throw new EigeneCheckedException();
				}
			}

		}
		if(!isAlpha2(eingabe))
		{
			String zwischenC;
			int cvonEingabe;
			for(char c : eingabe.toCharArray())
			{
				zwischenC = Character.toString(c);
				cvonEingabe = Integer.parseInt(zwischenC);
				System.out.println("ZahlenSystem in Int "+cvonEingabe);
				if(cvonEingabe >= ak_zs)
				{
					if(cvonEingabe == ',' || cvonEingabe == '-')
					{
						
					}
					else {
						System.out.println("ZahlenSystem in CHAR "+ak_zs);
					throw new EigeneCheckedException(
							 "Diese Zahl: "+ c +" ist in diesem Zahlensysten: " + ak_zs + " nicht erlaubt!"							
							+ " \n " +
							"Du solltest dir das Thema Zahlensysteme nochmal genauer anschauen" );
					}
				}
			}
			
		}
		

		// Plausi check ENDE

		System.out.println("");
		System.out.println("Auf Decimal Bringen");
		// ak_zs ==> aktuelles Zahlensystem
		// eingbae ==> eingabe

		// int ak_zs = 16; //aktuelles Zahlensystem
		// String eingabe = "18"; //zu konvertirende Zahl

		// s_Split funktion direkt eingebaut
		// String[] split = eingabe.split(""); //muss ersetze werden ==> / wurde ersetz
		String[] split = eingabeUmwandler(eingabe);
		// String[] split = s_Split(eingabe);

		// Ausgabe String Arry zerlegt Zahl
		for (int i = 0; i < split.length; i++)
			System.out.println("Die einzellen Teile: " + split[i]);

		// Adition Einzellner Teile
		int zwischenSpeicher = 0; // zwischenSpeicher f�r additon einzellner Stellen
		int stringTOint; // Zerlegte Teile des String Arrays in einen Int speichern
		int pM = 0; // potenz mutiplikator
		int mult; // mulitiplikartor

		for (int i = (split.length - 1); i >= 0; i--) {
			mult = (int) Math.pow(ak_zs, pM); // potenz der Aktuellen Stelle wird berechnet
			stringTOint = Integer.parseInt(split[i]);
			zwischenSpeicher = zwischenSpeicher + (stringTOint * mult); //
			System.out.println("Zwischen Ergebnis: " + zwischenSpeicher);
			pM++;
		}
		// Ausgabe Ergebnis in Decimal
		System.out.println("Ergebnis: " + zwischenSpeicher);
		return zwischenSpeicher;
	}

	public static double aufDecNachKOMMER(String eingabe, int ak_zs) throws EigeneCheckedException { // beliebiges
																										// Zahlensystem
																										// auf
		// Decimal bringen
		eingabe.toUpperCase();
// Plausi check
		if (eingabe.length() > 8) // stackoverflow vermeiden
		{
			throw new EigeneCheckedException("Eingabe zu gro�");
		}
		if (eingabe.isEmpty()) {
			throw new EigeneCheckedException("Eigabe ist leer");
		}

		if (ak_zs < 2 || ak_zs > 36) {
			System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 2-36");
			throw new EigeneCheckedException("Falsche Basis \n Die angegebene Basis liegt nicht im Bereich zwischen 2-36");
		}
// Eingabe pr�fen
		if (ak_zs <= 10) // pr�fe ob Buchstaben gebraucht werden wenn nicht wird geblockt
		{
			System.out.println("Basis kleiner 11!");
			System.out.println(eingabe);
			if (isAlpha2(eingabe)) // �berarbeiten!!!!!
			{
				System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 11-36");
				throw new EigeneCheckedException("Keine Buchstaben erlaubt \n Die angegebene Basis liegt nicht im Bereich zwischen 11-36");
			}

		}

		else {
			for (char c : eingabe.toCharArray()) {
				String cAufString = Character.toString(c);
				if (isAlpha2(cAufString)) {

					eingabe.toUpperCase();
// Pr�fen auf buchstaben mit charackter stadt swich case
					if (c < 'Z' - (25 - (ak_zs - 10)) && (c <= 'Z' && c >= 'A')) // welche Zahlen darf man verwenden
					{
						System.out.println("zwischen A-Z");
						System.out.println(c + ": ist erlaubt");
					} else if (c < 'z' - (25 - (ak_zs - 10)) && (c <= 'z' && c >= 'a')) {
						System.out.println("zwischen a-z");
						System.out.println(c + ": ist erlaubt");
					} else {
						System.out.println("NICHT ERLAUBT!!!");
						System.out.println(c + ": ist NICHT erlaubt");
						throw new EigeneCheckedException("Dieser Buchstabe: " + c + " ist bei dem aktuelen Zahlensystem(" + ak_zs + ") nicht erlaubt");
					}

				}
			}

		}

// Plausi check ENDE

		System.out.println("");
		System.out.println("Auf Decimal Bringen NACH KOMMER");
// ak_zs ==> aktuelles Zahlensystem
// eingbae ==> eingabe

// int ak_zs = 16; //aktuelles Zahlensystem
// String eingabe = "18"; //zu konvertirende Zahl

// s_Split funktion direkt eingebaut
// String[] split = eingabe.split(""); //muss ersetze werden ==> / wurde ersetz
		String[] split = eingabeUmwandler(eingabe);
// String[] split = s_Split(eingabe);

// Ausgabe String Arry zerlegt Zahl
		for (int i = 0; i < split.length; i++) {
			System.out.println("Die einzellen Teile von Postiton: ("+i+ ")" + split[i]);
		}

// Adition Einzellner Teile
		double zwischenSpeicher = 0; // zwischenSpeicher f�r additon einzellner Stellen
		double stringToDouble; // Zerlegte Teile des String Arrays in einen Int speichern
		double pM = -1; // potenz mutiplikator
		double mult; // mulitiplikartor

		for (int i = 0; i < split.length ; i++) {
			System.out.println("Zwischen Ergebnis : " + i+ " " +zwischenSpeicher);
			mult = (double) Math.pow(ak_zs, pM); // potenz der Aktuellen Stelle wird berechnet
			stringToDouble = Integer.parseInt(split[i]);
			zwischenSpeicher = zwischenSpeicher + (stringToDouble * mult); //
			System.out.println("Zwischen Ergebnis: " + zwischenSpeicher);
			pM--;
		}
// Ausgabe Ergebnis in Decimal
		System.out.println("Ergebnis NACH KOMMER: " + zwischenSpeicher*10);
		return zwischenSpeicher * 10;
	}

	public static String vonDecNachKommer(double eingabe, int zahlensytemAusgabe) throws EigeneCheckedException { // von
		System.out.println("vonDecNachKOMMER!!!!!!!:   "+ eingabe);																											// Decimal
																													// in
		// jedes andere
		// System
		// Plausi Check
		if (zahlensytemAusgabe < 2 || zahlensytemAusgabe > 36) // Basis wird gepr�ft
		{
			System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 2-36");
			throw new EigeneCheckedException("Falsche Basis  \n Die angegebene Basis liegt nicht im Bereich zwischen 2-36");
		}

		if (eingabe < 0) // Eingabe wird gepr�ft
		{
			System.err.println("Die angegebene Zahl liegt nicht im positiven Bereich oder ");
			throw new EigeneCheckedException("Falsche Eingabe \n  Die angegebene Zahl liegt nicht im positiven Bereich oder");
		}
		if (eingabe > Double.MAX_VALUE) {
			System.err.println("Stack Overflow----Zahl zu gro�");
			throw new EigeneCheckedException("Falsche Eingabe \n Stack Overflow----Zahl zu gro�");
		}

		// Plausi check ENDE

		System.out.println("");
		System.out.println("Von Decimal Umwandel NACH KOMMER");
		double eI = eingabe; // eingabe int INT / return wert der funkton aufDec
		double e2;
		e2 = eI;
		int zEi;
		int zsAusgabe = zahlensytemAusgabe; // Das gew�nschte Zahlensystem bei er Ausgabe
		String ausgabeE = "";
		// Zwischen Variblen f�r Divison

		ArrayList<String> e = new ArrayList<>();
		//double ergebnisZ;
		double rest = 0;
		// nachhkommer bereich
		int eingabeI = (int) eingabe;
		String eingabeString = String.valueOf(eingabeI);
		double nachkommer;
		int divisor = eingabeString.length();
		nachkommer = eingabe / (Math.pow(10, divisor));
		// Divison bis Null oder gewollte genauichkeit
		for (int i = 0; i < 7; i++) // bis 0 rechnen oder 15 nachkommer Stellen
		{
			if (i > 0) {
				nachkommer = rest;
			}
			e2 = zsAusgabe * nachkommer;
			zEi = (int) e2;
			System.out.println("Ausgabe vor SwichCASE !!!!!!!!! " + zEi);
			eD.add((double) zEi);

			rest = e2 - zEi;

			switch (zEi) // Zahlen �ber 9 in Buchstaben umwandeln / unter 9 in List �bergeben
			{
			case 10:
				e.add(i, "A");
				break;

			case 11:
				e.add(i, "B");
				break;

			case 12:
				e.add(i, "C");
				break;

			case 13:
				e.add(i, "D");
				break;

			case 14:
				e.add(i, "E");
				break;

			case 15:
				e.add(i, "F");
				break;

			case 16:
				e.add(i, "G");
				break;

			case 17:
				e.add(i, "H");
				break;

			case 18:
				e.add(i, "I");
				break;

			case 19:
				e.add(i, "J");
				break;

			case 20:
				e.add(i, "K");
				break;

			case 21:
				e.add(i, "L");
				break;

			case 22:
				e.add(i, "M");
				break;

			case 23:
				e.add(i, "N");
				break;

			case 24:
				e.add(i, "O");
				break;

			case 25:
				e.add(i, "P");
				break;

			case 26:
				e.add(i, "Q");
				break;

			case 27:
				e.add(i, "R");
				break;

			case 28:
				e.add(i, "S");
				break;

			case 29:
				e.add(i, "T");
				break;

			case 30:
				e.add(i, "U");
				break;

			case 31:
				e.add(i, "V");
				break;

			case 32:
				e.add(i, "W");
				break;

			case 33:
				e.add(i, "X");
				break;

			case 34:
				e.add(i, "Y");
				break;

			case 35:
				e.add(i, "Z");
				break;

			default:
				String ze = String.valueOf(zEi);
				e.add(i, ze);

			}
			System.out.println("Ergebnis Nach swich CASE !!!!!!!!!!!!!!!"+zEi);
			if (rest == 0) // ende der Rechnung wenn Ergebnis 0 ist
			{
				break;
			}

		}
		// Ausgabe ArrayList
		for (int i = 0; i < e.size(); i++) {
			System.out.println("ArrayList: NACHKOMMER=>>  " + e.get(i));
			
		}

		// Engl�ltige zusammengestze Ausgabe
		// Zusammensetzen der Einzellen Werte
		for (int i = 0; i < (e.size()); i++) {
			ausgabeE = ausgabeE + e.get(i);
			System.out.println("e.size: "+e.size()+" "+i+" Zwischgen Ausgabe:  NACKOMMER==> " + ausgabeE);
		}
		System.out.println(" \n  ");
		System.out.println("Endgl�ltige Ausgabe: NACKOMMER==>  " + ausgabeE);
		System.out.println("return wert: " + ausgabeE);

		// Ausgabe in Double zum rechnen WARSCHEINLICH UN�TIG
		double ergebnisTest = 0;
		double pow = -1;
		for (int i = 0; i < eD.size() - 1; i++) {

			ergebnisTest = ergebnisTest + (eD.get(i) * Math.pow(zahlensytemAusgabe, pow));
			System.out.println(ergebnisTest);
			pow--;
		}
		System.out.println("Ergebins IN DECIMAL / NACKOMMER==>  " + ergebnisTest);

		return ausgabeE;

	}

	public static String vonDec(int eingabe, int ZahlensytemAusgabe) throws EigeneCheckedException { // von Decimal in
		// jedes andere
		// System
// Plausi Check
		if (ZahlensytemAusgabe < 2 || ZahlensytemAusgabe > 36) // Basis wird gepr�ft
		{
			System.err.println("Die angegebene Basis liegt nicht im Bereich zwischen 2-16");
			throw new EigeneCheckedException("Falsche Basis \n  Die angegebene Basis liegt nicht im Bereich zwischen 2-16");
		}

		if (eingabe < 0) // Eingabe wird gepr�ft
		{
			System.err.println("Die angegebene Zahl liegt nicht im positiven Bereich oder ");
			throw new EigeneCheckedException("Falsche Eingabe \n Die angegebene Zahl liegt nicht im positiven Bereich oder");
		}
		if (eingabe > Integer.MAX_VALUE) {
			System.err.println("Stack Overflow----Zahl zu gro�");
			throw new EigeneCheckedException("Falsche Eingabe \n Stack Overflow----Zahl zu gro�");
		}

// Plausi check ENDE

		System.out.println("");
		System.out.println("Von Decimal Umwandel");
		int eI = eingabe; // eingabe int INT / return wert der funkton aufDec
		int zsAusgabe = ZahlensytemAusgabe; // Das gew�nschte Zahlensystem bei er Ausgabe

// Zwischen Variblen f�r Divison
		ArrayList<String> e = new ArrayList<>();
		int ergebnisZ;
		int rest;

// Divison bis Null
		for (int i = 0; i >= 0; i++) // gewollte Endlosschleife
		{
			rest = eI % zsAusgabe;
			eI = eI / zsAusgabe;

			switch (rest) // Zahlen �ber 9 in Buchstaben umwandeln / unter 9 in List �bergeben
			{
			case 10:
				e.add(i, "A");
				break;

			case 11:
				e.add(i, "B");
				break;

			case 12:
				e.add(i, "C");
				break;

			case 13:
				e.add(i, "D");
				break;

			case 14:
				e.add(i, "E");
				break;

			case 15:
				e.add(i, "F");
				break;

			case 16:
				e.add(i, "G");
				break;

			case 17:
				e.add(i, "H");
				break;

			case 18:
				e.add(i, "I");
				break;

			case 19:
				e.add(i, "J");
				break;

			case 20:
				e.add(i, "K");
				break;

			case 21:
				e.add(i, "L");
				break;

			case 22:
				e.add(i, "M");
				break;

			case 23:
				e.add(i, "N");
				break;

			case 24:
				e.add(i, "O");
				break;

			case 25:
				e.add(i, "P");
				break;

			case 26:
				e.add(i, "Q");
				break;

			case 27:
				e.add(i, "R");
				break;

			case 28:
				e.add(i, "S");
				break;

			case 29:
				e.add(i, "T");
				break;

			case 30:
				e.add(i, "U");
				break;

			case 31:
				e.add(i, "V");
				break;

			case 32:
				e.add(i, "W");
				break;

			case 33:
				e.add(i, "X");
				break;

			case 34:
				e.add(i, "Y");
				break;

			case 35:
				e.add(i, "Z");
				break;

			default:
				String ze = String.valueOf(rest);
				e.add(i, ze);

			}
			if (eI == 0) // ende der Rechnung wenn Ergebnis 0 ist
			{
				break;
			} else if (i == 1000000) {
				break;
			}
		}
// Ausgabe ArrayList
		for (int i = 0; i < e.size(); i++) {
			System.out.println("ArrayList: " + e.get(i));
		}

		String ausgabeE = "";// Engl�ltige zusammengestze Ausgabe
// Zusammensetzen der Einzellen Werte
		for (int i = (e.size() - 1); i >= 0; i--) {
			ausgabeE = ausgabeE + e.get(i);
			System.out.println("Zwischgen Ausgabe: " + ausgabeE);
		}
		System.out.println(" \n \n ");
		System.out.println("Endgl�ltige Ausgabe: " + ausgabeE);
		System.out.println("return wert: " + ausgabeE);
		return ausgabeE;
	}

	public static boolean isAlpha2(String text) throws EigeneCheckedException {// �berarbeiet
		boolean is = false;
		for (char c : text.toCharArray()) {

			// a - z
			if (c >= 'a' && c <= 'z') {
				is = true;
			}

			// A - Z
			if (c >= 'A' && c <= 'Z') {
				is = true;
			}
			if(c > 'z' && c <= '�')
			{
				throw new EigeneCheckedException(c+ "Ist ein Falscher Buchstabe");
			}

		}
		return is;
	}

	public static boolean isAF(String text) {
		boolean is = false;
		for (char c : text.toCharArray()) {

			// a - z
			if (c >= 'a' && c <= 'f') {
				is = true;
			}

			// A - Z
			if (c >= 'A' && c <= 'F') {
				is = true;
			}
			
			

		}
		return is;
	}
	
	  public static boolean isMinus(String s) //Pr�ft auf minus
	    {
	    	for (char c : s.toCharArray())
	    	{
				if(c == '-')
				{
					return true;
				}
				
			}
	    	return false;	    	
	    }
	

}
